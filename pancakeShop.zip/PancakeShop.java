import java.util.Random;

public class PancakeShop {
    public static void main(String[] args) {
        Random random = new Random();
        int totalTime = 0;
        int pancakesMade = 0;
        int pancakesEaten = 0;
        int unmetOrders = 0;
        int wastedPancakes = 0;

        while (totalTime < 180) {  // 3 cycles of 30 seconds each
            int shopkeeperPancakes = random.nextInt(13);  // Shopkeeper can make 0 to 12 pancakes
            int user1Order = random.nextInt(6);  // User 1 orders 0 to 5 pancakes
            int user2Order = random.nextInt(6);  // User 2 orders 0 to 5 pancakes
            int user3Order = random.nextInt(6);  // User 3 orders 0 to 5 pancakes

            int totalOrdered = user1Order + user2Order + user3Order;
            int totalAvailable = Math.min(shopkeeperPancakes, totalOrdered);

            pancakesMade += shopkeeperPancakes;
            pancakesEaten += totalAvailable;

            if (totalOrdered > totalAvailable) {
                unmetOrders += (totalOrdered - totalAvailable);
                wastedPancakes += (shopkeeperPancakes - totalAvailable);
            }

            System.out.println("30-second Slot: " + (totalTime / 30 + 1));
            System.out.println("Pancakes Made: " + shopkeeperPancakes);
            System.out.println("Pancakes Eaten: " + totalAvailable);
            System.out.println("Unmet Orders: " + (totalOrdered - totalAvailable));
            System.out.println("Wasted Pancakes: " + (shopkeeperPancakes - totalAvailable));
            System.out.println("------------------------------");

            totalTime += 30;
        }

        System.out.println("Total Pancakes Made: " + pancakesMade);
        System.out.println("Total Pancakes Eaten: " + pancakesEaten);
        System.out.println("Total Unmet Orders: " + unmetOrders);
        System.out.println("Total Wasted Pancakes: " + wastedPancakes);
    }
}
