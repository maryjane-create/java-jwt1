import java.util.Random;
import java.util.concurrent.CountDownLatch;

public class PancakeShop2 {
    public static void main(String[] args) throws InterruptedException {
        Random random = new Random();
        int totalTime = 0;
        int pancakesMade = 0;
        int pancakesEaten = 0;
        int unmetOrders = 0;
        int wastedPancakes = 0;

        while (totalTime < 180) {  // 3 cycles of 30 seconds each
            final CountDownLatch shopkeeperLatch = new CountDownLatch(1);
            final CountDownLatch userLatch = new CountDownLatch(3);
            final int[] shopkeeperPancakes = {0};
            final int[] totalOrdered = {0};
            final int[] totalAvailable = {0};

            // Simulate shopkeeper
            Thread shopkeeperThread = new Thread(() -> {
                shopkeeperPancakes[0] = random.nextInt(13);
                shopkeeperLatch.countDown();
            });

            // Simulate users
            Thread user1Thread = new Thread(() -> {
                try {
                    shopkeeperLatch.await();
                    totalOrdered[0] += random.nextInt(6);
                    userLatch.countDown();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

            Thread user2Thread = new Thread(() -> {
                try {
                    shopkeeperLatch.await();
                    totalOrdered[0] += random.nextInt(6);
                    userLatch.countDown();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

            Thread user3Thread = new Thread(() -> {
                try {
                    shopkeeperLatch.await();
                    totalOrdered[0] += random.nextInt(6);
                    userLatch.countDown();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

            shopkeeperThread.start();
            user1Thread.start();
            user2Thread.start();
            user3Thread.start();

            userLatch.await();

            totalAvailable[0] = Math.min(shopkeeperPancakes[0], totalOrdered[0]);
            pancakesMade += shopkeeperPancakes[0];
            pancakesEaten += totalAvailable[0];

            if (totalOrdered[0] > totalAvailable[0]) {
                unmetOrders += (totalOrdered[0] - totalAvailable[0]);
                wastedPancakes += (shopkeeperPancakes[0] - totalAvailable[0]);
            }

            System.out.println("30-second Slot: " + (totalTime / 30 + 1));
            System.out.println("Pancakes Made: " + shopkeeperPancakes[0]);
            System.out.println("Pancakes Eaten: " + totalAvailable[0]);
            System.out.println("Unmet Orders: " + (totalOrdered[0] - totalAvailable[0]));
            System.out.println("Wasted Pancakes: " + (shopkeeperPancakes[0] - totalAvailable[0]));

            totalTime += 30;
        }

        System.out.println("Total Pancakes Made: " + pancakesMade);
        System.out.println("Total Pancakes Eaten: " + pancakesEaten);
        System.out.println("Total Unmet Orders: " + unmetOrders);
        System.out.println("Total Wasted Pancakes: " + wastedPancakes);
    }
}

