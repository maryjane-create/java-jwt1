package com.example.brilloconnectz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrilloconnectzApplicationTests {

	@Test
	void contextLoads() {
	}

}
