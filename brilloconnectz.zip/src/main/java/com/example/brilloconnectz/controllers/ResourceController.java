package com.example.brilloconnectz.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.example.brilloconnectz.services.UserService;


@RestController
public class ResourceController {


       @Autowired
    private UserService userService;

    @GetMapping("/resource")
    public String getResource(@RequestHeader("Authorization") String authorizationHeader) {
        // Extract the JWT token from the Authorization header
        String token = authorizationHeader.substring(7);

        // Validate the token
        if (userService.validateToken(token)) {
            String username = userService.getUsernameFromToken(token);
            return "Access granted to resource for user: " + username;
        } else {
            return "Invalid token. Access denied.";
        }
    }
    
}
