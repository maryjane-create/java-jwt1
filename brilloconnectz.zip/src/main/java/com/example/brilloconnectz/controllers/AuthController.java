package com.example.brilloconnectz.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.brilloconnectz.services.UserService;
import com.example.brilloconnectz.models.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.Date;

@RestController
public class AuthController {

    @Autowired
    private UserService userService;

    private final String secretKey = "YourSecretKeyHere";

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        try {
            // Authenticate the user
            if (userService.authenticateUser(user.getUsername(), user.getPassword())) {
                // If authentication is successful, generate a JWT token and return it
                String token = generateJwtToken(user.getUsername());
                return ResponseEntity.ok(new JwtResponse(token));
            } else {
                // If authentication fails, return an error response
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication failed");
            }
        }
        catch (Exception e) {
            // Handle exceptions and return an error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
        }
    }

    private String generateJwtToken(String username) {
        // Set the expiration time for the token (e.g., 1 hour from now)
        Date expiration = new Date(System.currentTimeMillis() + 3600_000); // 1 hour in milliseconds

        // Build the JWT token
        String token = Jwts.builder()
                .setSubject(username)
                .setExpiration(expiration)
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();

        return token;
    }
}
