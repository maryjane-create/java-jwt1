package com.example.brilloconnectz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrilloconnectzApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrilloconnectzApplication.class, args);
	}

}
