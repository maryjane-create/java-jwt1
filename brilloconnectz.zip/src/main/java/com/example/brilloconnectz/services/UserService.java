package com.example.brilloconnectz.services;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;

@Service
public class UserService {

    private static final Key secretKey = Keys.secretKeyFor(SignatureAlgorithm.HS512);
    private final long expirationMs = 3600000; // 1 hour

    public String generateToken(String username) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expirationMs);

        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(secretKey)
                .compact();
    }

    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

    public boolean authenticateUser(String username, String password) {
        String sampleUsername = "sampleUser";
        String samplePassword = "samplePassword";

        // Check if the provided username and password match the expected values.
        if (username.equals(sampleUsername) && password.equals(samplePassword)) {
            return true; // Authentication successful
        } else {
            return false; // Authentication failed
        }
    }
}
